<?php
require "options/header.opt.php";
?>

<!-- Main -->
<section id="main" class="container">
	<header>
		<h2>Zorzella Davide</h2>
		<p>Full time Software dev. and Volleyball player</p>
	</header>
	<div class="row">
		<div class="col-12">

			<!-- Text -->
			<section class="box">
				<h3>My Time</h3>
				<p><code>while(true){ Davide.develop(); }</code></p>

				<hr />

				<header>
					<h3>Volleyball career</h3>
					<p>Monticelli d'Ongina</p>
				</header>
				<p>Dalla seconda elementare ho vestito i colori del Canottieri Ongina Volley, fino a quando...</p>
				<header>
					<p>Piacenza</p>
				</header>
				<p>... Piacenza mi ha aperto le porte ...</p>
				<header>
					<p>Trento</p>
				</header>
				<p>... ma giocare a Trento sarebbe il mio sogno.</p>

				<hr />

			</section>

		</div>
	</div>


</section>


<?php
require "options/footer.opt.php";
?>