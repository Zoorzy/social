<div id="main-user-img-delete">
  <form action="includes/deleteimgprofile.inc.php" method="post" enctype="multipart/form-data">
    <input type="submit" value="Delete Profile Image" name="submit" class="button">
  </form>
</div>