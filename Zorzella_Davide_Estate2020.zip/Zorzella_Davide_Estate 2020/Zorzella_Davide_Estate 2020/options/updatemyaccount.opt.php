<div id="main-user-account-update">
  <form id="updatemyaccount" action="updatemyaccount.php" method="POST" enctype="multipart/form-data">
    <input type="submit" value="Update My Account" class="button">
  </form>
</div>