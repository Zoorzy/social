<!-- Footer -->
<footer id="footer">
  <ul class="icons">
    <li><a href="#" class="icon brands fa-twitter"><span class="label">Twitter</span></a></li>
    <li><a href="#" class="icon brands fa-facebook-f"><span class="label">Facebook</span></a></li>
    <li><a href="https://www.instagram.com/zoorzy_/" target="_blank" class="icon brands fa-instagram"><span class="label">Instagram</span></a></li>
    <li><a href="#" class="icon brands fa-github"><span class="label">Github</span></a></li>
    <li><a href="#" class="icon brands fa-dribbble"><span class="label">Dribbble</span></a></li>
    <li><a href="#" class="icon brands fa-google-plus"><span class="label">Google+</span></a></li>
  </ul>
  <ul class="copyright">
    <li>&copy; Untitled. All rights reserved.</li>
    <li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
  </ul>
</footer>

</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/jquery.dropotron.min.js"></script>
<script src="assets/js/jquery.scrollex.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>

</body>

</html>